/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package last.attempt;

import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author lab_services_student
 */
public class AccountTest {
    
    public AccountTest() {
    }

    @Test
    public void testUserName() { 
    
     String expected = "kyl_1";
    
    String actual = getUsername();
    
    assertEquals(expected, actual);
      
}
    private String getUsername(){
        return "kyl_1";
    }

    @Test
    public void testPassword() { 
    
     String expected = "Ch&&sec@ke99!";
    
    String actual = getPassword();
    
    assertEquals(expected, actual);
      
}
    private String getPassword(){
        return "Ch&&sec@ke99!";
    }
}


    
    

