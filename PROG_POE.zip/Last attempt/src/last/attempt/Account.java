/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package last.attempt;

/**
 *
 * @author lab_services_student
 */
class Account {
    private String username;
    private String password;
    private String firstName;
    private String lastName;

    // Constructor
    public Account(String username, String password, String firstName, String lastName) {
        this.username = username;
        this.password = password;
        this.firstName = firstName;
        this.lastName = lastName;
    }

    Account() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    // create getters and setters to collect the input by user to create the app
    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    // methods used to check complexity of methods //YouTube · Alex Lee · 21 Feb 2019 Boolean Java Tutorial #15
    public boolean checkUsername() { 
        return username.length() <= 5 && username.contains("_");
    }

    // method to check password complexity
    public boolean checkPasswordComplexity() {
        return password.length() >= 8 && password.matches(".*[A-Z].*") && password.matches(".*\\d.*") && password.matches(".*[^a-zA-Z0-9].*");
    }

    // user registration 
    public String registerUser() {
        if (!checkUsername()) {
            return "The username you have entered is invalid, please ensure username contains an underscore and is no longer than 5 characters";
        } else if (!checkPasswordComplexity()) {
            return "The password you have entered is incorrectly formated, please ensure password is a has at least 8 characters, a captial letter, a number and a special character. ";
        } else {
            return "Registration successful.";
        }
    }

    // creates user login 
    public boolean loginUser(String enteredUsername, String enteredPassword) {
        return enteredUsername.equals(username) && enteredPassword.equals(password);
    }

    // returns message telling the user if they have entered the correct information or if the infomation is invalid
    public String returnLoginStatus(boolean loginStatus) {
        if (loginStatus) {
            return "Welcome " + firstName + " " + lastName;
        } else {
            return "Username or password incorrect please try again.";
        }
       
    }
}

//Reference List
//*jmj* 2023,J.Farrell ( java programming )
//Flanagan, D., 2005. Java in a Nutshell. " O'Reilly Media, Inc.".
//Harold, E.R., 2006. Java I/O: Tips and Techniques for Putting I/O to Work. " O'Reilly Media, Inc.".
// YouTube · Intellipaat · 26 Feb 2020 https://www.youtube.com/watch?v=xWBcGCKVOQA 
// YouTube · Alex Lee · 21 Feb 2019 https://www.youtube.com/watch?v=CHVVEGRGiJU