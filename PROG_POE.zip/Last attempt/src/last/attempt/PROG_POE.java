/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package last.attempt;

import javax.swing.JOptionPane;

/**
 *
 * @author lab_services_student
 */
public class PROG_POE {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        // get user information to create login 
        String username = JOptionPane.showInputDialog("Enter usersname - username must contain a maximum of 5 characters including an underscore:");
        String password = JOptionPane.showInputDialog("Create unique password - password must be minimum of 8 characters with a captital letter, a special character and a number:");
        String firstName = JOptionPane.showInputDialog("Enter first name:");
        String lastName = JOptionPane.showInputDialog("Enter last name:");

        // account class
        Account account = new Account(username, password, firstName, lastName);
  
        // register user and display registration status
        JOptionPane.showMessageDialog(null, account.registerUser());

        // to gain accesses into the account after creating it
        String enteredUsername = JOptionPane.showInputDialog("Enter your username:");
        String enteredPassword = JOptionPane.showInputDialog("Enter your password:");
        boolean loginStatus = account.loginUser(enteredUsername, enteredPassword);
        JOptionPane.showMessageDialog(null, account.returnLoginStatus(loginStatus));
    }
    }
    
